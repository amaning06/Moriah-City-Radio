
import { BibleChapterResponse } from "../types";

/**
 * Fetches a specific chapter from the Bible API.
 * Defaults to World English Bible (WEB) version.
 */
export const fetchBibleChapter = async (book: string, chapter: number): Promise<BibleChapterResponse | null> => {
  const url = `https://bible-api.com/${encodeURIComponent(book)} ${chapter}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch chapter");
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Bible fetch error:", error);
    return null;
  }
};
