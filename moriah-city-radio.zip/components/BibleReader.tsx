
import React, { useState, useEffect } from 'react';
import { ChevronLeft, Book as BookIcon, Hash, Search } from 'lucide-react';
import { BIBLE_BOOKS } from '../constants';
import { BibleBook, BibleChapterResponse } from '../types';
import { fetchBibleChapter } from '../services/bibleService';

export const BibleReader: React.FC = () => {
  const [view, setView] = useState<'books' | 'chapters' | 'reading'>('books');
  const [selectedBook, setSelectedBook] = useState<BibleBook | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null);
  const [content, setContent] = useState<BibleChapterResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredBooks = BIBLE_BOOKS.filter(b => 
    b.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectBook = (book: BibleBook) => {
    setSelectedBook(book);
    if (book.chapters === 1) {
      handleSelectChapter(1, book);
    } else {
      setView('chapters');
    }
  };

  const handleSelectChapter = async (chapter: number, bookOverride?: BibleBook) => {
    const book = bookOverride || selectedBook;
    if (!book) return;
    
    setSelectedChapter(chapter);
    setLoading(true);
    setView('reading');
    
    const data = await fetchBibleChapter(book.name, chapter);
    setContent(data);
    setLoading(false);
  };

  const goBack = () => {
    if (view === 'reading') {
      if (selectedBook?.chapters === 1) setView('books');
      else setView('chapters');
    } else if (view === 'chapters') {
      setView('books');
    }
  };

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right-4 duration-300">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        {view !== 'books' && (
          <button onClick={goBack} className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors">
            <ChevronLeft size={20} />
          </button>
        )}
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <BookIcon className="text-[#fdb147]" />
          {view === 'books' ? "Holy Bible" : selectedBook?.name}
          {view === 'reading' && selectedChapter && `: ${selectedChapter}`}
        </h2>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto pr-1">
        {view === 'books' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <input 
                type="text" 
                placeholder="Search books..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-[#fdb147]/50 transition-colors"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 pb-8">
              {filteredBooks.map((book) => (
                <button
                  key={book.name}
                  onClick={() => handleSelectBook(book)}
                  className="bg-white/5 p-4 rounded-2xl border border-white/5 hover:bg-[#fdb147]/10 hover:border-[#fdb147]/30 transition-all text-left group"
                >
                  <div className="font-bold text-white group-hover:text-[#fdb147] transition-colors">{book.name}</div>
                  <div className="text-[10px] text-gray-500 uppercase mt-1">{book.chapters} Chapters</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {view === 'chapters' && selectedBook && (
          <div className="grid grid-cols-5 gap-2 pb-8">
            {Array.from({ length: selectedBook.chapters }, (_, i) => i + 1).map((ch) => (
              <button
                key={ch}
                onClick={() => handleSelectChapter(ch)}
                className="aspect-square flex items-center justify-center bg-white/5 rounded-xl border border-white/5 hover:bg-[#fdb147] hover:text-[#1c0837] transition-all font-bold"
              >
                {ch}
              </button>
            ))}
          </div>
        )}

        {view === 'reading' && (
          <div className="space-y-6 pb-12 leading-relaxed">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 gap-4">
                <div className="w-8 h-8 border-4 border-[#fdb147] border-t-transparent rounded-full animate-spin"></div>
                <p className="text-gray-500 text-sm italic">Gathering scriptures...</p>
              </div>
            ) : content ? (
              <div className="animate-in fade-in duration-700">
                {content.verses.map((v) => (
                  <p key={v.verse} className="mb-4 text-gray-200">
                    <span className="text-[#fdb147] font-bold text-xs align-top mr-2 bg-[#fdb147]/10 px-1.5 py-0.5 rounded">
                      {v.verse}
                    </span>
                    {v.text}
                  </p>
                ))}
                <div className="pt-8 border-t border-white/5 flex justify-between gap-4">
                  {selectedChapter! > 1 && (
                    <button 
                      onClick={() => handleSelectChapter(selectedChapter! - 1)}
                      className="flex-1 py-3 bg-white/5 rounded-xl text-xs font-bold hover:bg-white/10 transition-colors"
                    >
                      PREVIOUS CHAPTER
                    </button>
                  )}
                  {selectedChapter! < selectedBook!.chapters && (
                    <button 
                      onClick={() => handleSelectChapter(selectedChapter! + 1)}
                      className="flex-1 py-3 bg-[#fdb147] text-[#1c0837] rounded-xl text-xs font-bold hover:opacity-90 transition-opacity"
                    >
                      NEXT CHAPTER
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-20 text-gray-500">
                <p>Unable to load chapter. Please check your connection.</p>
                <button onClick={() => handleSelectChapter(selectedChapter!)} className="mt-4 text-[#fdb147] font-bold underline">RETRY</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
