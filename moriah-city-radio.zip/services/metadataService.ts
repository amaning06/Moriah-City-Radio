
import { SongMetadata } from "../types";

/**
 * Fetches current song metadata for the Zeno FM stream.
 * Uses an aggressive proxy rotation strategy to bypass CORS and regional restrictions.
 */
export const fetchSongMetadata = async (mountKey: string, retries = 3): Promise<SongMetadata> => {
  // Ensure the mount key is clean
  const cleanMountKey = mountKey.trim();
  const targetUrl = `https://metadata.zeno.fm/${cleanMountKey}`;
  
  // Diversified list of proxies to handle different failure modes (400, 530, etc.)
  const proxyFactories = [
    // 1. AllOrigins (usually most reliable for Zeno)
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}&_=${Date.now()}`,
    // 2. Corsproxy.io
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    // 3. Codetabs Proxy
    (url: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`,
    // 4. Cloudflare Worker Proxy (Alternative pattern)
    (url: string) => `https://jsproxy.praz.dev/index.php?q=${encodeURIComponent(url)}`,
  ];

  // Randomize the starting proxy to distribute load and avoid sticky rate limits
  const startIdx = Math.floor(Math.random() * proxyFactories.length);

  for (let attempt = 0; attempt <= retries; attempt++) {
    const factoryIdx = (startIdx + attempt) % proxyFactories.length;
    const proxyUrl = proxyFactories[factoryIdx](targetUrl);
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout per attempt

    try {
      const response = await fetch(proxyUrl, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        }
      });
      
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const contentType = response.headers.get('content-type');
      const text = await response.text();

      // Validate that we actually got JSON and not a proxy error page
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        if (text.toLowerCase().includes('<html') || text.toLowerCase().includes('<!doctype')) {
          throw new Error("Proxy returned HTML instead of JSON (likely an error page)");
        }
        throw new Error("Invalid JSON format");
      }
      
      if (data && typeof data.title === 'string' && data.title.trim().length > 0) {
        const rawTitle = data.title.trim();
        
        // Clean up title strings from common stream artifacts
        const cleanTitle = rawTitle
          .replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'")
          .replace(/\s+/g, ' '); // Normalize whitespace
          
        const parts = cleanTitle.split(' - ');
        
        if (parts.length >= 2) {
          return {
            artist: parts[0].trim(),
            title: parts.slice(1).join(' - ').trim()
          };
        }
        
        return {
          artist: "Moriah City Radio",
          title: cleanTitle
        };
      }
      
      throw new Error("Metadata empty or invalid structure");

    } catch (error: any) {
      clearTimeout(timeoutId);
      
      const isTimeout = error.name === 'AbortError';
      const isLastAttempt = attempt === retries;

      // Silent logs for production stability
      console.debug(`[Metadata] Attempt ${attempt + 1} (${proxyFactories[factoryIdx].name}): ${isTimeout ? 'Timeout' : error.message}`);

      if (!isLastAttempt) {
        // Shorter delay between retries to maintain UX snappiness
        const delay = 800 + (Math.random() * 400);
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
    }
  }

  // Guaranteed fallback metadata
  return {
    artist: "Moriah City Radio",
    title: "Your Divine Connection"
  };
};
