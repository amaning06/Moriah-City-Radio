
import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, Pause, Share2, Info, Star, Volume2, VolumeX, ShieldCheck, 
  Heart, Radio, Settings, Music, BookOpen, Clock, X, ChevronRight,
  Home, ExternalLink
} from 'lucide-react';
import { APP_CONFIG } from './constants';
import { PlayerStatus, InsightData, SongMetadata } from './types';
import { Visualizer } from './components/Visualizer';
import { BibleReader } from './components/BibleReader';
import { getHostInsight } from './services/geminiService';
import { fetchSongMetadata } from './services/metadataService';

const App: React.FC = () => {
  const [status, setStatus] = useState<PlayerStatus>(PlayerStatus.IDLE);
  const [insight, setInsight] = useState<InsightData | null>(null);
  const [metadata, setMetadata] = useState<SongMetadata>({ artist: "MCPMI", title: "Live Broadcast" });
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [activeTab, setActiveTab] = useState<'player' | 'bible' | 'settings'>('player');
  const [showSleepTimer, setShowSleepTimer] = useState(false);
  const [sleepTimer, setSleepTimer] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    fetchInsight();
    updateMetadata();
    const insightInterval = setInterval(fetchInsight, 300000); 
    const metadataInterval = setInterval(updateMetadata, 30000); 
    return () => {
      clearInterval(insightInterval);
      clearInterval(metadataInterval);
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, []);

  const fetchInsight = async () => {
    try {
      const data = await getHostInsight();
      setInsight(data);
    } catch (err) {
      console.error("Insight error:", err);
    }
  };

  const updateMetadata = async () => {
    const mountKey = "fnw5m2488f0uv"; 
    const data = await fetchSongMetadata(mountKey);
    setMetadata(data);
  };

  const togglePlayback = () => {
    if (!audioRef.current) return;
    if (status === PlayerStatus.PLAYING) {
      audioRef.current.pause();
      setStatus(PlayerStatus.IDLE);
    } else {
      setStatus(PlayerStatus.LOADING);
      audioRef.current.play()
        .then(() => setStatus(PlayerStatus.PLAYING))
        .catch((err) => {
          console.error("Playback failed", err);
          setStatus(PlayerStatus.ERROR);
        });
    }
  };

  const setTimer = (minutes: number) => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    setSleepTimer(minutes * 60);
    setShowSleepTimer(false);
    timerRef.current = window.setInterval(() => {
      setSleepTimer((prev) => {
        if (prev === null || prev <= 1) {
          if (audioRef.current) {
            audioRef.current.pause();
            setStatus(PlayerStatus.IDLE);
          }
          if (timerRef.current) window.clearInterval(timerRef.current);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const shareApp = () => {
    if (navigator.share) {
      navigator.share({
        title: APP_CONFIG.name,
        text: `I'm listening to ${metadata.title} on ${APP_CONFIG.name}. Tune in!`,
        url: window.location.href,
      });
    }
  };

  return (
    <div className="h-screen text-white flex flex-col max-w-[440px] mx-auto relative overflow-hidden bg-[#2d0a50] shadow-2xl">
      {/* Dynamic Background with Logo-Themed Glow */}
      <div className="absolute inset-0 z-0 pointer-events-none transition-all duration-1000">
        <div 
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: `url('${APP_CONFIG.logoUrl}')`,
            backgroundSize: '150%',
            backgroundPosition: 'center',
            filter: 'blur(100px)',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#8C338A]/20 via-[#2d0a50]/80 to-[#2d0a50]" />
      </div>

      <audio
        ref={audioRef}
        src={APP_CONFIG.streamUrl}
        crossOrigin="anonymous"
        onCanPlay={() => { if(status === PlayerStatus.LOADING) setStatus(PlayerStatus.PLAYING); }}
        onError={() => setStatus(PlayerStatus.ERROR)}
      />

      {/* Header */}
      <header className="px-6 pt-10 pb-4 flex justify-between items-center z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center backdrop-blur-xl border border-white/20 p-1.5 shadow-2xl overflow-hidden">
            <img 
              src={APP_CONFIG.logoUrl} 
              alt="Logo" 
              className={`w-full h-full object-contain ${status === PlayerStatus.PLAYING ? 'animate-[spin_12s_linear_infinite]' : ''}`} 
            />
          </div>
          <div>
            <h1 className="font-black text-lg leading-tight tracking-tight text-white">MCPMI RADIO</h1>
            <div className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${status === PlayerStatus.PLAYING ? 'bg-[#E31E24] animate-pulse shadow-[0_0_8px_#E31E24]' : 'bg-gray-500'}`}></span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Live Broadcast</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => setShowSleepTimer(true)}
          className={`p-3 rounded-2xl bg-white/5 border border-white/10 text-white/70 hover:text-[#FDB147] transition-all ${sleepTimer ? 'border-[#FDB147] text-[#FDB147]' : ''}`}
        >
          <Clock size={22} />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 pb-24 z-10 overflow-y-auto scrollbar-hide">
        {activeTab === 'player' && (
          <div className="flex flex-col items-center space-y-8 py-4 animate-in fade-in zoom-in-95 duration-700">
            {/* Logo and Prophetic Animation - Spinning when Live */}
            <div className="relative mt-2">
              <div className={`absolute inset-0 bg-[#FDB147] rounded-full blur-[80px] opacity-20 transition-transform duration-[4000ms] ${status === PlayerStatus.PLAYING ? 'scale-150' : 'scale-50'}`}></div>
              <div className={`w-72 h-72 rounded-full overflow-hidden border-[12px] border-white/10 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.6)] bg-white/5 p-6 flex items-center justify-center transition-all duration-1000 ${status === PlayerStatus.PLAYING ? 'opacity-100' : 'opacity-80'}`}>
                <img 
                  src={APP_CONFIG.logoUrl} 
                  alt="Moriah City Logo" 
                  className={`w-full h-full object-contain drop-shadow-2xl transition-transform duration-1000 ${status === PlayerStatus.PLAYING ? 'scale-110 animate-[spin_8s_linear_infinite]' : 'scale-90 rotate-0'}`}
                />
              </div>
            </div>

            {/* Now Playing Info */}
            <div className="text-center w-full space-y-3">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FDB147]/10 border border-[#FDB147]/20 mb-1">
                <Music size={12} className={status === PlayerStatus.PLAYING ? "animate-bounce text-[#FDB147]" : "text-white/40"} />
                <span className="text-[10px] uppercase font-black tracking-[0.2em] text-[#FDB147]">Prophetic encounter</span>
              </div>
              <h2 className="text-3xl font-black truncate px-2 leading-tight tracking-tight drop-shadow-lg">{metadata.title}</h2>
              <p className="text-white/50 font-medium text-sm uppercase tracking-[0.3em]">{metadata.artist}</p>
            </div>

            <Visualizer isPlaying={status === PlayerStatus.PLAYING} />

            {/* Play Controls */}
            <div className="w-full space-y-8">
              <div className="flex items-center justify-around gap-2">
                <button 
                  onClick={shareApp}
                  className="p-5 rounded-[2.5rem] bg-white/5 hover:bg-white/10 border border-white/5 transition-all text-white/60 hover:text-white"
                >
                  <Share2 size={24} />
                </button>
                
                <button 
                  onClick={togglePlayback}
                  className="w-24 h-24 rounded-full bg-[#FDB147] flex items-center justify-center text-[#2d0a50] shadow-[0_20px_40px_-10px_rgba(253,177,71,0.6)] active:scale-90 transition-all hover:scale-105 relative group overflow-hidden"
                >
                  <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                  {status === PlayerStatus.LOADING ? (
                    <div className="w-10 h-10 border-4 border-[#2d0a50] border-t-transparent rounded-full animate-spin"></div>
                  ) : status === PlayerStatus.PLAYING ? (
                    <Pause size={42} fill="currentColor" className="relative z-10" />
                  ) : (
                    <Play size={42} className="ml-1 relative z-10" fill="currentColor" />
                  )}
                </button>

                <button 
                  onClick={() => setActiveTab('settings')}
                  className="p-5 rounded-[2.5rem] bg-white/5 hover:bg-white/10 border border-white/5 transition-all text-white/60 hover:text-white"
                >
                  <Info size={24} />
                </button>
              </div>

              {/* Volume Slider - Themed */}
              <div className="flex items-center gap-4 bg-white/5 p-4 rounded-[2.5rem] border border-white/10 backdrop-blur-3xl">
                <button onClick={() => setIsMuted(!isMuted)} className="text-[#FDB147] transition-colors">
                  {isMuted || volume === 0 ? <VolumeX size={22} /> : <Volume2 size={22} />}
                </button>
                <input 
                  type="range" min="0" max="1" step="0.01" value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    setVolume(v);
                    if (audioRef.current) audioRef.current.volume = v;
                    setIsMuted(false);
                  }}
                  className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#FDB147]"
                />
              </div>

              {/* Gemini Insight - Themed with Fire Accents */}
              {insight && (
                <div className="relative group overflow-hidden animate-in slide-in-from-bottom-4 duration-700 delay-300">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-[#FDB147] via-[#E31E24] to-[#8C338A] rounded-[2.5rem] blur opacity-15 group-hover:opacity-30 transition duration-1000"></div>
                  <div className="relative bg-white/5 backdrop-blur-3xl p-7 rounded-[2.5rem] border border-white/10 space-y-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-[#E31E24] animate-ping"></div>
                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#FDB147]">Prophetic Insight</span>
                      </div>
                      <Radio size={14} className="text-white/20" />
                    </div>
                    <h3 className="font-black text-base text-white">{insight.title}</h3>
                    <p className="text-sm text-white/70 italic leading-relaxed">"{insight.content}"</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'bible' && <BibleReader />}

        {activeTab === 'settings' && (
          <div className="space-y-8 animate-in slide-in-from-right-8 duration-700 pt-4">
            <h2 className="text-4xl font-black tracking-tighter">MINISTRY</h2>
            
            <div className="space-y-4">
              <div className="bg-white/5 p-7 rounded-[2.5rem] border border-white/10 shadow-xl">
                <p className="text-white/80 leading-relaxed text-sm font-medium">
                  Moriah City Prophetic Ministry International (MCPMI) is a global lighthouse of hope, bringing the undiluted word of God to the ends of the earth.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button className="flex flex-col items-center justify-center gap-3 bg-white/5 p-6 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                  <Heart className="text-[#FDB147] group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold uppercase tracking-[0.2em]">Partner</span>
                </button>
                <button className="flex flex-col items-center justify-center gap-3 bg-white/5 p-6 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                  <Star className="text-[#FDB147] group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold uppercase tracking-[0.2em]">Support</span>
                </button>
              </div>

              <div className="bg-[#FDB147] p-7 rounded-[2.5rem] text-[#2d0a50] flex justify-between items-center group cursor-pointer shadow-2xl hover:brightness-105 transition-all active:scale-[0.98]">
                <div>
                  <h4 className="font-black text-xl tracking-tight">Visit Website</h4>
                  <p className="text-xs font-bold opacity-60">https://moriahcityradio.com</p>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-[#2d0a50]/10 flex items-center justify-center">
                  <ExternalLink size={24} />
                </div>
              </div>

              <div className="pt-6 border-t border-white/10 opacity-60">
                <div className="flex items-center gap-3 text-white px-2">
                  <ShieldCheck size={18} className="text-[#FDB147]" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Privacy Protected</span>
                </div>
                <p className="mt-3 text-[11px] text-white/50 px-2 leading-relaxed italic">
                  Built for the glory of God, and his sanctuary is safe. Therefore we are committed to protecting your privacy.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation - Refined */}
      <nav className="fixed bottom-6 left-6 right-6 h-23 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/10 flex items-center justify-around z-50 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        <button 
          onClick={() => setActiveTab('player')}
          className={`relative flex flex-col items-center justify-center gap-1.5 w-1/3 h-full transition-all ${activeTab === 'player' ? 'text-[#FDB147]' : 'text-white/30'}`}
        >
          <Home size={20} fill={activeTab === 'player' ? 'currentColor' : 'none'} />
          <span className="text-[10px] font-black uppercase tracking-widest">Radio</span>
          {activeTab === 'player' && <div className="absolute bottom-2 w-1.2 h-1.2 rounded-full bg-[#FDB147]"></div>}
        </button>
        <button 
          onClick={() => setActiveTab('bible')}
          className={`relative flex flex-col items-center justify-center gap-1.5 w-1/3 h-full transition-all ${activeTab === 'bible' ? 'text-[#FDB147]' : 'text-white/30'}`}
        >
          <BookOpen size={20} fill={activeTab === 'bible' ? 'currentColor' : 'none'} />
          <span className="text-[10px] font-black uppercase tracking-widest">Bible</span>
          {activeTab === 'bible' && <div className="absolute bottom-2 w-1.2 h-1.2 rounded-full bg-[#FDB147]"></div>}
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`relative flex flex-col items-center justify-center gap-1.5 w-1/3 h-full transition-all ${activeTab === 'settings' ? 'text-[#FDB147]' : 'text-white/30'}`}
        >
          <Settings size={20} fill={activeTab === 'settings' ? 'currentColor' : 'none'} />
          <span className="text-[10px] font-black uppercase tracking-widest">Info</span>
          {activeTab === 'settings' && <div className="absolute bottom-2 w-1.2 h-1.2 rounded-full bg-[#FDB147]"></div>}
        </button>
      </nav>

      {/* Sleep Timer Modal - Themed */}
      {showSleepTimer && (
        <div className="absolute inset-0 z-[100] bg-black/70 backdrop-blur-md flex items-end animate-in fade-in duration-500">
          <div className="w-full bg-[#2d0a50] rounded-t-[3.5rem] p-8 pb-12 border-t border-white/10 animate-in slide-in-from-bottom-full duration-700">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black tracking-tighter">Set Sleep Timer</h3>
              <button onClick={() => setShowSleepTimer(false)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><X size={20} /></button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[15, 30, 45, 60].map((min) => (
                <button 
                  key={min}
                  onClick={() => setTimer(min)}
                  className="p-7 rounded-[2.5rem] bg-white/5 border border-white/10 hover:border-[#FDB147] hover:bg-[#FDB147]/10 transition-all text-left group"
                >
                  <span className="block text-3xl font-black mb-1 group-hover:text-[#FDB147] transition-colors">{min}</span>
                  <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Minutes</span>
                </button>
              ))}
              {sleepTimer && (
                <button 
                  onClick={() => { setSleepTimer(null); if(timerRef.current) clearInterval(timerRef.current); setShowSleepTimer(false); }}
                  className="col-span-2 mt-2 p-6 rounded-[2rem] bg-[#E31E24]/10 border border-[#E31E24]/30 text-[#E31E24] font-black uppercase tracking-widest text-xs hover:bg-[#E31E24]/20 transition-all"
                >
                  Deactivate Timer ({formatTime(sleepTimer)})
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Global Status Banner - Themed with Logo Red */}
      {status === PlayerStatus.ERROR && (
        <div className="absolute top-12 left-6 right-6 bg-[#E31E24] p-5 rounded-3xl flex items-center justify-between z-[60] shadow-2xl animate-in slide-in-from-top-10 duration-500">
          <div className="flex items-center gap-3">
            <Radio className="text-white animate-pulse" size={20} />
            <span className="font-black text-xs uppercase tracking-widest">Stream Interrupted</span>
          </div>
          <button onClick={() => { setStatus(PlayerStatus.IDLE); togglePlayback(); }} className="bg-white text-[#E31E24] px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-transform">Retry</button>
        </div>
      )}
    </div>
  );
};

export default App;
