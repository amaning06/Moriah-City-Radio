
export interface StationConfig {
  name: string;
  slogan: string;
  streamUrl: string;
  logoUrl: string;
  primaryColor: string;
  accentColor: string;
}

export enum PlayerStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  PLAYING = 'PLAYING',
  ERROR = 'ERROR',
}

export interface SongMetadata {
  title: string;
  artist: string;
}

export interface InsightData {
  title: string;
  content: string;
}

// Bible Types
export interface BibleVerse {
  book_name: string;
  chapter: number;
  verse: number;
  text: string;
}

export interface BibleChapterResponse {
  reference: string;
  verses: BibleVerse[];
  text: string;
}

export interface BibleBook {
  name: string;
  chapters: number;
}
