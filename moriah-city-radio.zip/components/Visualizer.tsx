
import React, { useEffect, useState } from 'react';
import { APP_CONFIG } from '../constants';

interface VisualizerProps {
  isPlaying: boolean;
}

export const Visualizer: React.FC<VisualizerProps> = ({ isPlaying }) => {
  const [bars, setBars] = useState<number[]>(new Array(15).fill(4));

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setBars(prev => prev.map(() => Math.floor(Math.random() * 50) + 10));
      }, 100);
    } else {
      setBars(new Array(15).fill(4));
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <div className="flex items-center justify-center gap-1.5 h-20 w-full px-8">
      {bars.map((height, i) => (
        <div
          key={i}
          className="w-1.5 rounded-full transition-all duration-150 shadow-[0_0_10px_rgba(253,177,71,0.2)]"
          style={{ 
            height: `${height}%`, 
            opacity: isPlaying ? 1 : 0.2,
            backgroundColor: i % 2 === 0 ? APP_CONFIG.accentColor : '#ffffff',
            transform: isPlaying ? 'scaleY(1)' : 'scaleY(0.5)'
          }}
        />
      ))}
    </div>
  );
};
