
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";
import { InsightData } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Fetches a radio host insight with retry logic to handle transient 500 errors.
 */
export const getHostInsight = async (retries = 3): Promise<InsightData> => {
  const model = "gemini-3-flash-preview";
  
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: "Generate a warm welcome and an uplifting thought for our listeners right now.",
        config: {
          systemInstruction: SYSTEM_PROMPT,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
            },
            required: ["title", "content"],
          },
          // Disable thinking for low-latency basic text tasks to avoid proxy timeouts
          thinkingConfig: { thinkingBudget: 0 }
        },
      });

      if (!response || !response.text) {
        throw new Error("Empty response from Gemini API");
      }

      const result = JSON.parse(response.text.trim());
      return result as InsightData;
    } catch (error) {
      console.warn(`Gemini API Attempt ${attempt + 1} failed:`, error);
      
      // If this was the last attempt, return the fallback content
      if (attempt === retries - 1) {
        return {
          title: "Staying Connected",
          content: "Thank you for tuning in to Moriah City Radio. We are blessed to have you with us today.",
        };
      }
      
      // Wait before retrying (exponential backoff: 1s, 2s, 4s...)
      const delay = Math.pow(2, attempt) * 1000;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  // Final fallback (safety)
  return {
    title: "Moriah City Radio",
    content: "Your Divine Connection. Stay tuned for uplifting music and spiritual growth.",
  };
};
